# Proxy (Velocity) runs as mcproxy
tmux new-session -s minecraft -n velocity "bash -c 'cd /home/mcproxy/velocity && sudo -u mcproxy java -Xmx1G -jar velocity-3.4.0-SNAPSHOT-464.jar; exec bash'" \; \
    split-window -h "bash -c 'cd /home/mcauth/auth && sudo -u mcauth java -Xmx1G -jar paper-1.12.2-1620.jar nogui; exec bash'" \; \
    split-window -h "bash -c 'cd /home/mcqueue/queue && sudo -u mcqueue java -Xmx2G -jar paper-1.12.2-1620.jar nogui; exec bash'" \; \
    split-window -v "bash -c 'cd /home/mcmain/world && sudo -u mcmain java -Xmx6G -jar paper-1.12.2-1620.jar nogui; exec bash'" \; \
    select-layout tiled \; \
    attach
